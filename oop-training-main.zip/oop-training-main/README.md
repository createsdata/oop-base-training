# Object Oriented Programming
Welkom Creators bij de workshop 'Object Oriented Programming'! Kijk gerust alvast in de opdrachten, maar niet stiekem naar de antwoorden ;-) Veel succes!